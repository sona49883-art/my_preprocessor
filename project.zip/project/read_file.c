#include "header.h"
int read_file(char *file, char ***data)
{
	FILE *fp=fopen(file,"r");
	int count=0,max=0,lines=0;
	char ch;
	while((ch=fgetc(fp))!=EOF)
	{
		count++;
		if(ch=='\n')
		{
			lines++;
			if(count>max)
				max=count;
			count=0;
		}
	}
	rewind(fp);
	char s[max+1];
	*data=malloc(sizeof(char *)*lines);
	int i=0;
	while(fgets(s,sizeof(s),fp))
	{
		(*data)[i]=malloc(sizeof(char)*max);
		strcpy((*data)[i],s);
		i++;
	}
	fclose(fp);
	return lines;
}

