#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct{
	char m_name[100];
	char *m_body;
}mac; 

extern int m_count;//counting macros

int read_file(char *,char***);
void command(char **,int);
mac** macro(char **,int);
//void header_inclu(char **,int);
