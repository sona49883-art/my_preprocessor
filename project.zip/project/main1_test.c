#include"header.h"
int m_count=0;
int main(int argc,char **argv)
{
	if(argc!=2)
	{
		fprintf(stderr,"USAGE: ./aout file_name.c\n");
		return 1;
	}

	char **data;
	int lines=read_file(argv[1],&data);     //--->file scaned in heap
	command(data,lines);                    //--->removes command
	mac **table=macro(data,lines);          //--->scan, store and remove macro 

	char out_file[20];
	strcpy(out_file,argv[1]);
	char *p=strchr(out_file,'.');
	if(p) {*(p+1)='i'; }           //input.i

	FILE *dfp=fopen(out_file,"w");
	char path[100]="/usr/include/";

	for(int n=0;n<lines;n++)
	{
		char file[200],dest[100];
		int i=0;
		if(strstr(data[n],"#include"))
		{
			char *p=strchr(data[n],'<');
			p++;
			while((*p)!='>')
				file[i++]=*p++;
			file[i]='\0';
			strcpy(dest,path);
			strcat(dest,file);
			FILE *sfp=fopen(dest,"r");
			while(fgets(file,sizeof(file),sfp))
				fputs(file,dfp);
			fclose(sfp);
		}
		else
			fputs(data[n],dfp);
	}


	fclose(dfp);
	for(int i=0;i<lines,i++)
		free(data[i]);
	free(data);
	for(int i=0;i<20;i++)
	{
		free(table[i]->m_body);
		free(table[i]);
	}
	return 0;
}
