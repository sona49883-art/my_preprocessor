#include "header.h"
#define M_BODY_SIZE 50
mac** macro(char **data,int lines)
{
	int t=0,i;
	m_count=0;
	mac **table ;
	table=malloc(sizeof(mac*)*20);
	for(int i=0;i<20;i++)
	{
		table[i]=malloc(sizeof(mac));
		table[i]->m_body=malloc(sizeof(M_BODY_SIZE));
	}

	for(int n=0;n<lines;n++)
	{
		char *p,*q,ch;
		if(strstr(data[n],"#define"))
		{
			if(p=strchr(data[n],' '))//use for store [m_name]
			{
				i=0;
				p++;
				while(*p!=' ')
					table[t]->m_name[i++]=*p++;
				table[t]->m_name[i]='\0';
			}
			p++;
			if(*p=='{')//used for multiple line macros [m_body]
			{	
				int i=0,c=1,size=M_BODY_SIZE;
				table[t]->m_body[i++]=*p++;//store '{' also
				while((*p)!='}')
				{
					if(*p==' ')
					{
						p++;
						continue;
					}
					if(*p=='\\')
					{
						//	data[n][0]='\n';
						data[n][0]='\0';
						p=data[++n];
						continue;
					}
					table[t]->m_body[i++]=*p++;
					c++;
					if(c>M_BODY_SIZE-1)
					{
						size+=50;
						table[t]->m_body=realloc(table[t]->m_body,size);
						c=0;
					}

				}
				table[t]->m_body[i++]=*p;
				table[t]->m_body[i]='\0';
				//data[n][0]='\n';
				data[n][0]='\0';
				t++;
				m_count++;
			}
			else//used for single line macro [m_body]
			{
				int i=0;
				while(*p!='\n')//why '\n'? bcoz #define MAX 100\n\0
					table[t]->m_body[i++]=*p++;
				table[t]->m_body[i++]='\0';//here
				//data[n][0]='\n';
				data[n][0]='\0';
				t++;
				m_count++;
			}
		}
	}

	//for(int i=0;i<t;i++)
	//	printf("%s %s",table[i]->m_name,table[i]->m_body);
	return table;
}
/*
void replace(mac **table,char**data,int lines,int t)
{
	for(int n=0;n<lines;n++)
	{
		if(data[n][0]!='#')
		{
			for(int i=0;i<t;i++)
			{
				char *p;
				if(*p=strstr(data[n],table[i]->m_name))
				{
					int n_len=strlen(*/

