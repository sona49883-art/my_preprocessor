#include"header.h"
int find_macro(char *,mac**,FILE*);
int m_count=0;
int main(int argc,char **argv)
{
	if(argc!=2)
	{
		fprintf(stderr,"USAGE: ./aout file_name.c\n");
		return 1;
	}

	char **data;
	int lines=read_file(argv[1],&data);     //--->file scaned in heap
	command(data,lines);                    //--->removes command
	mac **table=macro(data,lines);          //--->[scan->store->return] and remove macro 
	//opening ____ .i file
	char out_file[20];
	strcpy(out_file,argv[1]);
	char *p=strchr(out_file,'.');
	if(p) {*(p+1)='i'; }           //input.i

	FILE *dfp=fopen(out_file,"w");
	char path[100]="/usr/include/";

	for(int n=0;n<lines;n++)
	{
		char file[200],dest[100],*mptr;
		int i=0;
		//Expand header to output.i file
		if(strstr(data[n],"#include"))
		{
			char *p=strchr(data[n],'<');
			p++;
			while((*p)!='>')
				file[i++]=*p++;
			file[i]='\0';
			strcpy(dest,path);
			strcat(dest,file);
			FILE *sfp=fopen(dest,"r");
			while(fgets(file,sizeof(file),sfp))
				fputs(file,dfp);
			fclose(sfp);
		}
		//if line contain macro, then replace and write to output.i file
		else if(find_macro(data[n],table,dfp))
		{
			continue;
		}
		//if line is normal ,direct write to output.i file
		else
			fputs(data[n],dfp);
	}
	//cleaning
	fclose(dfp);
	for(int i=0;i<lines;i++)
		free(data[i]);
	free(data);
	for(int i=0;i<20;i++)
	{
		free(table[i]->m_body);
		free(table[i]);
	}
	return 0;
}
int find_macro(char *data,mac**table,FILE *dfp)
{
	char *p,str[200];
	for(int i=0;i<m_count;i++)
	{
		if((p=strstr(data,table[i]->m_name))!=NULL)
		{
			int mlen=strlen(table[i]->m_name),n=0;
			while((data+n)!=p)
			{
				str[n]=data[n];
				n++;
			}
			str[n]='\0';
			strcat(str,table[i]->m_body);
			strcat(str,p+mlen);
			fputs(str,dfp);
		//	printf("%s",str);
			return 1;
		}	
	}	
	return 0;}
