----C_Main_project_PREPROCESSOR-----

responsible for :
    * HeaderFile inclution
    * macro replacement
        -single line macro replacement
        -multi line macro replacement
    * commment remove
        - single_line
        - multi_line

files-
1.header.h
2.command.c
3.macro.c
4.read_file.c
5.main.c

sample input file -> input.c 
output file you obtain with same "input_file_name".i with .i extention

compilation:
    cc main.c command.c macro.c read_file.c  ----> a.out
execution:
    ./a.out sample_input_src_file.c
    (eg: ./a.out input.c)

pending:makefile