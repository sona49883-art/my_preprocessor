#include "header.h"
void command(char **data,int lines)
{
	for(int n=0;n<lines;n++)
	{
		char *p;
		if(p=strstr(data[n],"//"))//singleline_cmd
		{
			*p='\n';
			*++p='\0';
			continue;
		}
		if(p=strstr(data[n],"/*"))
		{
			*p++='\n';
			*p++='\0';
			if(strstr(p,"*/"))//if it is present in same line eg:/* hello world*/
				continue;
			for(n=n+1;n<lines;n++)//checking next-next lines
			{
				if(p=strstr(data[n],"*/"))
				{
					*p++='\n';
					*p='\0';
					break;
				}
				data[n][0]='\n';
				data[n][1]='\0';
			}
		}
	}
}

