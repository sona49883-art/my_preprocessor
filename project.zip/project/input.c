#include<stdio.h>
#include<string.h>
#define MAX 100
#define MIN 50
#define INCREMENT_BOTH(x,y) {\
    (x)++, \
    (y)++ \
    }
void fun();
int main()
{
	int a=MIN;  // test
	printf("%d %d",a,MAX);
	/*
	   multiline line command test1
	   test2
	   test3
	*/
	fun();
}
void fun(int a)
{
	if(a)
		INCREMENT_BOTH(x,y)
	else
		printf("fails!");
}
